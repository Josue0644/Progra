﻿using System;

namespace L1_JDSC_1064022
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese su nombre:");
            String nombre = Console.ReadLine();
            
            Console.WriteLine("Hola Mundo");
            Console.WriteLine("soy Josue" + "");

            Console.Write("Hola Mundo");
            Console.Write(" " + "soy Josue");
            Console.ReadKey();
        }
    }
}
