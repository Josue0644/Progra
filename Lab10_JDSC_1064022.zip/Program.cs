﻿// See https://aka.ms/new-console-template for more information
static void Menu()
{
    double r, area, per, vol;
    string x;

    Console.WriteLine("Ingrese el radio");
    r = Int32.Parse(Console.ReadLine());

    area = Math.Pow(r, 2);
    per = Math.PI;
    vol = (1.33) * (Math.PI) * Math.Pow(r, 3);

    while (true)
    {
        Console.WriteLine("Ingrese la funcion que se requiere");
        Console.WriteLine("Area");
        Console.WriteLine("Volumen");
        Console.WriteLine("Perimetro");
        x = Convert.ToString(Console.ReadLine());

        switch (x)
        {
            case "Area":
                Console.WriteLine("Area = " + area);
                break;

            case "Perimetro":
                Console.WriteLine("Perimetro = " + per);
                break;

            case "Volumen":
                Console.WriteLine("Volumen = " + vol);
                break;
        }
        Console.ReadKey();
    }
}
